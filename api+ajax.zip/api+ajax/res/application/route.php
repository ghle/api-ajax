<?php

use think\Route;

Route::get('lis', 'Index/index');
